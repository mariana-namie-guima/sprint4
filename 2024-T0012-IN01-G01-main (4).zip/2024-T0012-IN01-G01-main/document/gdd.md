<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/38e79dd447c90b26fd07077eba34799b34613f77/document/assets/logointeli.png">


# GDD - Game Design Document - Módulo 1 - Inteli

**_Os trechos em itálico servem apenas como guia para o preenchimento da seção. Por esse motivo, não devem fazer parte da documentação final_**

## Pontual.org - UniLevel

#### Ana Beatriz Passos Beggiato
#### Eduardo Farias Rizk
#### Felipe de Melo Elgenneni
#### Fernanda Correia Nascimento
#### Lucas Guerra Vicente
#### Mariana Namie Guima
#### Pedro El Haouli Faria



## Sumário

[1. Introdução](#c1)

[2. Visão Geral do Jogo](#c2)

[3. Game Design](#c3)

[4. Desenvolvimento do jogo](#c4)

[5. Casos de Teste](#c5)

[6. Conclusões e trabalhos futuros](#c6)

[7. Referências](#c7)

[Anexos](#c8)

<br>


# <a name="c1"></a>1. Introdução (sprints 1 e 4)

## 1.1. Escopo do Projeto

### 1.1.1. Contexto da indústria (sprints 1 e 4)

&nbsp;&nbsp;&nbsp;&nbsp; A indústria dos bens de consumo, uma das maiores do mundo, é responsável por cerca de 15% do faturamento industrial brasileiro <sup>1</sup>, abrange desde alimentos até cuidados pessoais e limpeza, sendo “Unilever” <sup>2</sup>, “Nestlé” <sup>3</sup>, “Coca-Cola” <sup>4</sup> e “Procter & Gamble” <sup>5</sup> os principais players desse ramo - somando uma receita anual de aproximadamente 196,313 bilhões de reais, o equivalente a quase 10% do faturamento anual brasileiro <sup>6</sup>. Essas empresas buscam a diferenciação de seus modelos de negócio por meio de publicidade e criação de novas experiências de uso para tentar atrair novos clientes <sup>7<sup>, mas todas estão investindo em tecnologia de uma forma ou outra. No mais, as tendências entre essas multinacionais estão seguindo três pontos principais, sendo eles a personalização, a sustentabilidade e a inovação em seus produtos. Assim, por ser um mercado altamente competitivo, muitas empresas estão tentando se adaptar às novas demandas de mercado e consumo para manter sua posição e tentar ampliar suas atividades.



### 1.1.2. Análise SWOT (sprints 1 e 4)

&nbsp;&nbsp;&nbsp;&nbsp;Análise SWOT é uma ferramenta utilizada para avaliação de cenários antes do lançamento de um projeto <sup>8</sup>, e sua utilização pode ser muito benéfica, principalmente, para uma tomada de decisão estratégicas com relação aos rumos do projeto, assim como para a obtenção de insights relacionados à solução dos possíveis problemas do projeto em questão. No mais, essa ferramenta permite a análise de fatores interno e externos, positivos e negativos, que impactam diretamente um projeto ou empresa, permitindo assim uma visão mais clara dos passos a serem tomados no desenvolvimento de um novo produto ou projeto.



<div align="center">
<sub>Figura X - Análise SWOT </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/4bca001bc9030b905f104939211e19df87167099/document/assets/matrizSWOT.png">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

&nbsp;&nbsp;&nbsp;&nbsp;Conforme a análise SWOT, a Unilever traz forças como ser uma empresa global, ter grande influência nos mercados atuantes e boa imagem. Como fraquezas, temos mercados saturados, diversificação de produtos em áreas com alta inflação. Além disso, a demanda mundial por empresas sustentáveis e a participação da empresa globalmente abre um grande leque de oportunidades. Já as ameaças são o risco de imitação de produtos, flutuações cambiais e de mudanças regulatórias e preocupações ambientais, podendo impactar diretamente as operações e a reputação da empresa.


### 1.1.3. Descrição da Solução Desenvolvida (sprints 1 e 4)


&nbsp;&nbsp;&nbsp;&nbsp;Atualmente, a Unilever encontra-se no processo de estruturação de seu Onboarding para funcionários de TI recém-contratados, tendo como principal desafio o engajamento deles nesse processo, garantindo a absorção de todas as informações transmitidas. Dado que a empresa é adepta do modelo de trabalho HibridUS <sup>9</sup>, uma necessidade pós pandêmica que proporciona aos funcionários maior tempo em contato com ferramentas tecnológicas, e que os novos colaboradores estão geralmente destinados às carreiras júnior - e, por isso, costumam ser mais jovens -, a solução proposta precisa abranger o ambiente web e não pode parecer infantil.

&nbsp;&nbsp;&nbsp;&nbsp;Diante desse cenário, a solução proposta consiste no desenvolvimento de uma aplicação interativa que proporcionará uma experiência envolvente na qual o colaborador, representado por um personagem virtual, navegará pelas instalações da empresa, desempenhando tarefas que têm como propósito transmitir de maneira eficaz os valores e missões da empresa, tal como demais informações cruciais presentes no processo de integração. Podendo ser acessado pelo próprio colaborador em seu notebook de trabalho, o jogo deve ser iniciado após o processo geral de Onboarding da empresa, para que o funcionário passe a ter contato com as informações específicas de sua área - como explicações sobre determinados vocabulários e processos.

&nbsp;&nbsp;&nbsp;&nbsp;Através da utilização desta aplicação, será possível não só motivar o funcionário a realizar o Onboarding, mas também garantir que ele tenha acesso a todas as informações necessárias para integrar-se na empresa. No mais, a organização poderá verificar a realização ou não do processo, assim como o nível de absorção das informações por parte do novo colaborador.

&nbsp;&nbsp;&nbsp;&nbsp;Ademais, visando mensurar o sucesso da aplicação, será utilizado o nível de aceitação dos funcionários quanto a ferramenta, assim como a eficácia dela no que tange a realização do processo de Onboarding e a absorção das informações nele transmitidas.


### 1.1.4. Proposta de Valor (sprints 1 e 4)

&nbsp;&nbsp;&nbsp;&nbsp;Um Canvas de Proposta de Valor é definido visando visualizar, projetar e testar a criação de valor da empresa para o cliente <sup>10</sup>. Assim, foi desenvolvido para o jogo em questão o seguinte Canvas de Proposta de Valor:



<div align="center">
<sub>Figura X - Proposta de Valor </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/c52a62cf27686c4210751dac4ce8ef8b35d954c9/document/assets/Value%20proposition%20canvas.png">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

&nbsp;&nbsp;&nbsp;&nbsp;Por meio da imagem acima, observa-se que a maior dor do cliente está relacionada ao seu processo de Onboarding, que precisa transmitir muitas informações, mas não consegue fazê-lo de forma atrativa para os funcionários. Por isso, o principal “analgésico” proposto é o desenvolvimento de um jogo que permita à empresa oferecer um processo de Onboarding gamificado, garantindo assim uma atratividade maior e, consequentemente, uma maior absorção de informações por parte dos funcionários, permitindo com que estejam integrados e produtivos desde seu primeiro contato com a empresa.


### 1.1.5. Matriz de Riscos (sprints 1 e 4)

&nbsp;&nbsp;&nbsp;&nbsp;Pensando na gestão de crise e risco, foi desenvolvida para esse jogo uma Matriz de Probabilidade e Impacto, a qual tem como principal objetivo a identificação prévia de possíveis riscos e oportunidades do projeto, permitindo um planejamento prévio das ações a serem tomadas na ocorrência desses eventos.

<div align="center">
<sub>Figura X - Matriz de risco </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/c52a62cf27686c4210751dac4ce8ef8b35d954c9/document/assets/matrizderisco.png">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

Diante disso, com a Matriz realizada, faz-se necessário traçar uma análise dos impactos e possíveis planos de ação para cada risco identificado. Abaixo, observa-se essa análise:

- **Queda de energia na empresa no momento da realização do jogo:** esse é um risco de baixa probabilidade e baixo impacto, visto que o prédio sede da empresa tem gerador de energia <sup>11</sup> e, além disso, o jogo pode ser acessado pelos celulares dos funcionários através do navegador. 
- **Falta de informações disponíveis para o desenvolvimento do jogo:** esse é um risco de baixa probabilidade - visto que os desenvolvedores já possuem a maioria das informações necessárias para o desenvolvimento do game -, mas que tem um médio impacto no jogo, dado que a indisponibilidade de informações relacionadas ao onboarding da empresa leva o jogo a não cumprir plenamente seu objetivo. Diante disso, é função do grupo 
- **Má interpretação, por parte dos funcionários, das informações fornecidas no game:** esse é um risco de média probabilidade, dado que o desenvolvimento do jogo visa apresentação clara das informações. Entretanto, a efetivação desse risco teria um alto impacto para o jogo, visto que sua principal funcionalidade é exatamente essa: transmitir as informações sobre a empresa com clareza.
- **Ocorrência de bugs no jogo:** esse é um risco de baixa probabilidade - em função da realização de diferentes testes antes do lançamento do game -, mas de alto impacto, já que impediria a experiência plena do usuário para com o jogo. Assim, efetivando-se a ocorrência de bugs, é função dos programadores aumentar os casos de teste, visando identificar e corrigir todas as intercorrências de funcionamento do jogo. 
- **Queda do servidor responsável pela hospedagem do game:** esse é um risco de baixa probabilidade, em função da estabilidade dos servidores web já consolidados, mas de muito alto impacto, visto que a queda de servidor representa, ao jogo, sua indisponibilidade momentânea. Assim, ocorrendo uma queda de servidor, será necessária a emissão, na página do game, de um aviso de indisponibilidade momentânea, visando deixar o usuário ciente de que precisará tentar acessar o site em outro momento.
- **Perda dos arquivos de desenvolvimento do jogo:** esse é um risco de baixa probabilidade, porque o grupo usa plataformas web para desenvolvimento e, além disso, armazena muitos arquivos em nuvem com backup diário. Entretanto, uma perda de arquivos teria um impacto muito alto no projeto, já que pode representar a perda, também, do jogo. Por isso, é dever do grupo manter seus backups diários e, em caso de perda de um ou vários arquivos, buscar por restaurar a versão imediatamente anterior do jogo, minimizando assim os prejuízos de desenvolvimento.
- **Maior prestígio do processo de onboarding da Unilever:** essa é uma oportunidade com alta probabilidade de acontecimento, visto que o onboarding da empresa já é muito bem avaliado <sup>12</sup>, e sua gamificação apenas traria ainda mais prestígio. Ainda, essa é uma oportunidade de alto impacto no jogo, visto que o prestígio da empresa seria, também, direcionado ao jogo, possibilitando sua aplicação em outros setores e empresas. A fim de garantir esse aumento de prestígio, é dever da equipe de marketing do jogo divulgar não só sua funcionalidade, mas também sua aplicabilidade e funcionalidade.
- **Metaverso como plataforma para ampliar a experiência imersiva do jogo:** essa é uma oportunidade de alta probabilidade e alto impacto, visto que o metaverso tem se desenvolvido cada vez mais rápido <sup>13</sup>, e tem elevado potencial para aumentar a imersividade e interatividade da maioria das práticas digitais, como no game em questão. Assim, para efetivar a ocorrência de tal fato, será dever da equipe de TI adaptar o jogo ao ambiente do metaverso assim que ele estiver disponível e acessível para todos os usuários da internet.



## 1.2. Requisitos do Projeto (sprints 1 e 2)
\# | Requisito  
--- | ---
1 | Apresentar a organização e divisão da área de IT
2 | Apresentação do mundo Unilever (informações públicas da empresa)
3 | Apresentar o que é UniOps
4 | Ambientação web
5 | Ser uma trilha indidvidual
6 | Apresentar o compromisso da empresa com a sustentabilidade
7 | Metrificar a absorção do conteúdo por parte do jogador
8 | Colher feedback sobre o conteúdo do game
9 | Ser um HUB de links
10 | Incluir checkpoints
11 | Ter uma página ou fase de tutorial
12 | Ter interação com NPCs
13 | Resolução de tarefas ao longo do jogo


## 1.3. Público-alvo do Projeto (sprint 2)

&nbsp;&nbsp;&nbsp;&nbsp;Traçar o público-alvo de qualquer produto a ser lançado é de suma importância para seu desenvolvimento, visto que possibilita uma visão mais clara dos requisitos do projeto, assim como possibilita uma maior aceitação dos usuários para com o produto, já que ele foi pensado para esse público. Quando tratando-se de um jogo que será utilizado no processo de Onboarding de uma empresa, faz-se necessário entender não só o nível de instrução dos funcionários dessa empresa que utilizarão o jogo, mas também sua idade e sua experiência prévia com jogos.
<div align="center">
<sub>Figura X - Público Alvo </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/319a8213f465f7667638491deec56de4d63f46de/document/assets/publicoAlvo(02).png">
<sup>Fontes: LinkedIn da Unilever e questionário enviado para a Unilever.</sup>
</div>
<div align="center">
<sub>Figura X - Público Alvo </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/319a8213f465f7667638491deec56de4d63f46de/document/assets/publicoAlvo(03).jpg">
<sup>Fontes: LinkedIn da Unilever e questionário enviado para a Unilever.</sup>
</div>
<div align="center">
<sub>Figura X - Público Alvo </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/9d1e3ef6375681d325444e2792d58e1245a43028/document/assets/p%C3%BAblico_alvo.jpg">
<sup>Fontes: LinkedIn da Unilever e questionário enviado para a Unilever.</sup>
</div>

&nbsp;&nbsp;&nbsp;&nbsp;Diante de uma análise de público-alvo realizada por meio da análise do LinkedIn <sup>14</sup> da Unilever e de uma pesquisa de campo feita por um grupo parceiro (GreenTech), chegou-se à conclusão de que o jogo não precisa ser projetado especificamente para pessoas que nunca jogaram, pois a maioria dos entrevistados já tem experiência com jogos, variando de títulos simples a jogos como Call of Duty. Isso simplifica o desenvolvimento do jogo, permitindo que aspectos básicos, como movimentação e interação com bots, sejam intuitivos para os jogadores. No mais, ficou constatado que os potenciais usuários do game são residentes principalmente no México, Espanha e Argentina, além do Brasil, o que nos leva à necessidade de desenvolver o jogo em línguas latinas ou no inglês (língua universal), e a faixa etária dos jogadores gira em torno dos 30 a 40 anos.

<div align="center">
<sub>Figura X - Público Alvo </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/319a8213f465f7667638491deec56de4d63f46de/document/assets/publicoAlvo(04).jpg">
<sup>Fontes: LinkedIn da Unilever e questionário enviado para a Unilever.</sup>
</div>


# <a name="c2"></a>2. Visão Geral do Jogo (sprint 2)

## 2.1. Objetivos do Jogo (sprint 2)

&nbsp;&nbsp;&nbsp;&nbsp;O intuito primário do jogo é resgatar as marcas da Unilever do controle de um Hacker que invadiu o seu sistema. Para combatê-lo, o jogador precisa terminar as fases respondendo uma pergunta, que lhe concederá uma sílaba-chave para desligar o sistema do hacker. Tendo isso em mente, o game procura indiretamente tornar o Onboarding uma experiência leve e divertida para os novos funcionários da Unilever, por meio da mescla entre o jogo de plataforma e as perguntas.

## 2.2. Características do Jogo (sprint 2)

### 2.2.1. Gênero do Jogo (sprint 2)

&nbsp;&nbsp;&nbsp;&nbsp;Pensando em criar um jogo que se encaixe aos gostos do público alvo do jogo, ou seja, aos novos funcionários da Unilever; foi criado um formulário com as opções de preferências por diferentes gêneros de jogos. Segundo as respostas recebidas, grande parte dos dados coletados indicou uma tendência à escolha de games de ação e aventura e, por conta disso, foi desenvolvido um jogo que mistura a fantasia das marcas da Unilever com a aventura de resgatá-las de um hacker. 

### 2.2.2. Plataforma do Jogo (sprint 2)

&nbsp;&nbsp;&nbsp;&nbsp;A plataforma de um jogo é o local ou servidor em que o game é carregado e exibido aos jogadores; assim, ele pode ser rodado em desktops, mobiles, etc. Por conta dos requisitos propostos pelo cliente, o jogo desenvolvido rodará na Web de dispositivos desktop. 

### 2.2.3. Número de jogadores (sprint 2)

&nbsp;&nbsp;&nbsp;&nbsp;A fim de facilitar o controle de dados da progressão de cada participante no Onboarding, o jogo apresentará somente um jogador, visto que isso otimiza a interação dele com os conteúdos e links da Unilever. Além disso, uma trilha individual permite uma melhor análise do aproveitamento do conteúdo por parte do jogador.

### 2.2.4. Títulos semelhantes e inspirações (sprint 2)

&nbsp;&nbsp;&nbsp;&nbsp;O jogo se inspirou em "Super Mario Bro.", uma vez que utilizou a dinâmica de plataformas e inimigos para que o player encontre desafios. Além disso, durante a progressão do jogo, aparecem em certas fases objetos que causam danos aos personagens de diversas formas, como encostando nele ou caindo sobre ele. Ademais, há um quiz no final da fase inspirado em "Trivia Quest", jogo da Netflix, sendo utilizado para testar os conhecimentos do jogador sobre a Unilever, assim como computar o seu aprendizado por um sistema de pontuações. 

### 2.2.5. Tempo estimado de jogo (sprint 5)

&nbsp;&nbsp;&nbsp;&nbsp;Visto que o percurso durante as fases do jogo dura cerca de 5 minutos e o jogo possui três fases, uma introdutória e duas jogáveis, de cerca de 2 minutos, conclui-se que o jogo tem uma duração de cerca de quinze minutos. Entretanto, esse tempo pode variar m função da necessidade de leitura dos links disponibilizados durante o jogo, sendo esse tempo de leitura relativo a cada usuário e à extensão do conteúdo abordado.


# <a name="c3"></a>3. Game Design (sprints 2 e 3)

## 3.1. Enredo do Jogo (sprints 2 e 3)

&nbsp;&nbsp;&nbsp;&nbsp;A primeira cena do jogo UniLevel é ambientada na casa do personagem controlável, o Ursinho Fofo, que anda até o computador posicionado na mesa do seu escritório e encontra nele uma notificação pop-up. Nessa notificação, um hacker descreve seu plano de tomar a Unilever para si, roubando as marcas e mantendo-as em um cativeiro protegido por senha. Em função disso, o jogador fica encarregado de salvar cada uma das marcas por meio da obtenção das letras da senha, e para isso é teletransportado por meio de um portal mágico para dentro do próprio computador.

&nbsp;&nbsp;&nbsp;&nbsp;Após isso, o personagem é teletransportado,  encontrando o primeiro cenário: O Mundo OMO, um espaço azul escuro com plataformas de pregador de roupa, diversas bolhas de sabão e roupas penduradas ou jogadas em todo canto. Seu primeiro objetivo é passar pelas bactérias das roupas sujas e alcançar a YoUNI, NPC onipresente guia de jornada responsável por mostrar o caminho de acesso às informações (link) que o jogador precisará para desbloquear a primeira letra da senha que está em busca. Chegando ao final da fase de plataforma, o personagem depara-se com uma tela de perguntas, na qual será testado sobre o conteúdo do link oferecido. Acertando a pergunta, o personagem é liberado para a próxima fase, recebe a primeira letra da senha que está procurando e libera o personagem “Omo”. 

&nbsp;&nbsp;&nbsp;&nbsp;Seguindo por um portal, o jogador vai para o próximo cenário: A Floresta da Mãe Terra, um mundo repleto de árvores e plantações, porém infestado com besouros que comem os biscoitos naturais que brotam da terra. Seguindo por plataformas desses mesmos comestíveis e suas embalagens, o jogador alcança YoUNI, recebendo outro link e mais uma pergunta, que, ao ser respondida corretamente, liberta a segunda letra e o Jacaré Zooreta.


&nbsp;&nbsp;&nbsp;&nbsp; Logo após sair de outro portal, é apresentado ao jogador o banheiro da Dove, coberto por azulejos, shampoos e condicionadores. Nessa fase, o nível de dificuldade da plataforma é aumentado, uma vez que o jogador é arrastado pela força de propulsão de um desodorante ao longo do piso ensaboado, escorregando pelos azulejos até uma bolha de fedor, o inimigo da fase. Quando alcançar YoUNI, é liberado o terceiro link e pergunta que, ao ser acertada, libera a letra e a Pomba da Dove.

&nbsp;&nbsp;&nbsp;&nbsp;Na saída seguinte, o jogador se depara com o Freezer Kibon, um mundo doce com montanhas de sorvete, canudos de chocolate e colheres. O inimigo dessa fase não é um NPC, mas gotas de cobertura derretida caindo do teto do freezer, que podem atingir o jogador. Seguindo a mesma lógica das anteriores, o objetivo é alcançar a mentora, desbloqueando o link, a pergunta, a letra e, dessa vez, o Picolé Tablito.

&nbsp;&nbsp;&nbsp;&nbsp;Em sequência, é mostrada a ‘Dogueria’ da Hellmann 's, um espaço coberto por um cachorro-quente gigante com molhos da marca. Aqui, as plataformas são baseadas nos recipientes dos condimentos - os tubos de mostarda e ketchup -  e,  dessa vez, o vilão
 é um exército de batatas palha, que atrapalham o alcance do fim. Encontrando YoUNI, são liberados os materiais necessários para a passagem de nível e o Pote de Maionese.

&nbsp;&nbsp;&nbsp;&nbsp; Por último, o jogador chega no Mar de Letrinhas da Knorr, uma sopa gigante com massas flutuando. Seu principal desafio será passar por plataformas verticais semelhantes ao jogo “Flappy Bird”, evitando encostar nos garfos gigantes que estão nas extremidades da sopa. Quando alcança a NPC guia no meio do mapa, ele desbloqueia os conteúdos para conseguir a última letra e retoma sua jornada fugindo das plataformas. Ao fim, ele recupera a galinha do Caldo Knorr quando responde corretamente o quiz.


&nbsp;&nbsp;&nbsp;&nbsp;Quando alcançado o final do jogo, o usuário precisa inserir as seis letras obtidas para abrir o cofre e salvar a Unilever do hacker. Assim que essa missão é cumprida, o mesmo portal do início se abre, teletransportando o personagem de volta para sua casa. Agora, os personagens salvos aparecem no ambiente, agradecendo pela coragem do jogador e finalizando o jogo.


## 3.2. Personagens (sprints 2 e 3)

### 3.2.1. Controláveis

&nbsp;&nbsp;&nbsp;&nbsp;Os personagens são modelos em pixel art baseados no Ursinho Fofo, mascote embaixador da marca de amaciantes Fofo da Unilever. Os controláveis homônimos seguem a mesma paleta de cores do rebranding divulgado em 2023, sendo quatro opções de escolha: Azul, bege, rosa-vermelho e laranja-roxo. Seu design é baseado primariamente nas sprites do Megaman 1987, da Capcom para o Nintendo Entertainment System.

&nbsp;&nbsp;&nbsp;&nbsp;Os objetivos delegados ao personagem vão desde a leitura dos documentos e acesso dos links enviados pela Unilever até a resposta de perguntas relacionadas a esses conteúdos, desbloqueando letras de uma palavra-chave a ser utilizada para salvar os NPC-marcas do ataque de hackers. Durante a realização de tarefas, o jogador consegue mover a persona para frente, para trás e pular em um modelo plataforma de mundo. Além disso, tendo em vista que, apesar de estar preso em um mundo virtual, o controlável é uma personificação do funcionário de TI, foi acordado pela equipe de não incluir habilidades sobre humanas ou de luta. 

### 3.2.2. Non-Playable Characters (NPC)

&nbsp;&nbsp;&nbsp;&nbsp;Ao longo do jogo, existem quatro tipos de NPC´s: O hacker, vilão principal do jogo que aparece por meio de mensagens no computador do personagem controlável; o personagem que direciona o acesso aos links no meio de cada fase; as próprias marcas a serem salvas e os capangas de cada nível. Cada um deles segue a paleta de cores especificada no Kit Media enviado pela Unilever ou a cor padrão dos produtos já existentes e também se comportam como modelos em pixel art.

&nbsp;&nbsp;&nbsp;&nbsp;O hacker não apresenta características físicas e se comporta apenas como pop-ups no computador do personagem. 

&nbsp;&nbsp;&nbsp;&nbsp;Por sua vez, o NPC guia YoUNI, que dá acesso aos links, possui a aparência de uma mulher azul que utiliza um hijab branco e roupas rosa pastel, baseada em uma das personagens autorais da própria Unilever.

&nbsp;&nbsp;&nbsp;&nbsp;Os NPC-marcas são os que apresentam características mais diversas, sendo:
* OMO: O NPC da marca é uma caixa de sabão em pó que comporta o branding antigo da marca (anos 2000), metade do corpo dividido em tons de vermelho e azul vibrantes com pontos de luz brancos no centro.
* Mãe Terra: O NPC da marca é o jacaré da linha alimentícia Zooreta, a versão escolhida foi a paleta de cores do salgadinho assado de queijo, contando com uma blusa branca, casaco laranja e calça azul com detalhes em amarelo.
* Dove: O NPC da marca é a pomba característica dos produtos em seu rebranding mais atual, cor dourada com textura metálica brilhante, que reluz um ponto de luz branco em seu centro.
* Kibon: O NPC da marca é o picolé Tablito, um sorvete de palito com a parte externa em paletas de cor off-white (chocolate branco) repleto de pontinhos amarelados (amendoins) e interior marrom (chocolate ao leite). Esse personagem também conta com um palito em um tom marrom mais claro e uma “mordida” em seu topo, seguindo o modelo da foto que embala o próprio picolé em sua versão atual.
* Hellmann’s: O NPC da marca é o pote de maionese característico de 500g. Ele segue a mesma paleta de cores do produto original porém um aspecto mais personificado para dar mais “vida” ao personagem.
* Knorr: O NPC da marca é a galinha que ilustra a caixinha de Caldo Knorr sabor galinha. Ela possui uma paleta de cores branca em seu interior e um contorno vermelho no exterior, seguindo o modelo que aparece estampado nos produtos. Seu vime e crista seguem a mesma tonalidade avermelhada, no entanto, fugindo do usual, seu bico é branco.

&nbsp;&nbsp;&nbsp;&nbsp;Da mesma forma, cada nível apresenta seus respectivos capangas, NPCs cujo objetivo é atrapalhar a passagem de fase, assim, eles se comportam como:
* OMO: Os NPCs capangas da marca são bactérias das roupas sujas que atacam o jogador, fazendo-o voltar para o início da fase e dificultando seus avanços. Elas seguem uma paleta de cores voltada para o rosa e fímbrias (protuberâncias) amareladas, contrastando com o tom azulado do background.
* Mãe Terra: Os NPCs capangas da marca são besouros que atacam o jogador. Eles comportam cores mais escuras voltadas para o marrom e o preto. contrastando com o verde do background folhado.
* Dove: Os NPCs capangas da marca são bolhas de sujeira e fedor que incapacitam o avanço do jogador. Elas possuem tons transparentes voltados para o verde e o marrom, além de semblantes furiosos. 
* Kibon: A marca não possui NPCs capangas, ao invés disso, a dificuldade da fase está em escapar de gotas de cobertura derretida caindo do topo da tela.
* Hellmann’s: Os NPCs capangas da marca são exércitos de batata palha, que carregam lanças pretas afiadas. Eles seguem uma tonalidade amarela mais vibrante com detalhes em marrom, representando um gradiente característico de fritura, além de possuírem rostos bravos.
* Knorr: A marca não possui NPCs capangas, ao invés disso, são colocadas plataformas verticais no estilo “Flappy Bird” que o jogador deve evitar.

### 3.2.3. Diversidade e Representatividade dos Personagens

&nbsp;&nbsp;&nbsp;&nbsp;No jogo UniLevel, os personagens foram  criados propositalmente com aparências não humanoides , inspirando-se nos mascotes de diversas marcas da Unilever. Essa escolha abrange uma ampla gama de seres, desde jacarés até ursos e embalagens, evitando estereótipos ligados a qualquer etnia ou cultura específica. Essa abordagem tem um efeito inclusivo e universalizador, pois ao optar por personagens que não remetem a nenhum grupo humano em particular, o jogo consegue representar a todos. Essa estratégia assegura que os jogadores de diferentes backgrounds possam se engajar com o jogo sem se sentirem excluídos ou estereotipados, promovendo uma experiência de jogo acolhedora e acessível.

&nbsp;&nbsp;&nbsp;&nbsp;Em resumo, a escolha de personagens não humanos  é uma jogada que amplia o alcance do jogo, tornando-o acessível e atraente para um público-alvo quase ilimitado. Isso não só maximiza o potencial de engajamento dos jogadores, mas também fortalece sua posição como uma experiência inclusiva e engajadora que se preocupa com a diversidade e a inclusão.



## 3.3. Mundo do jogo (sprints 2 e 3)

### 3.3.1. Locações Principais e/ou Mapas (sprints 2 e 3)

&nbsp;&nbsp;&nbsp;&nbsp;O jogo ocorre em um cenário lúdico, o qual representa a temática de um dos produtos da Unilever em cada fase.  Abaixo, segue uma tabela com as fases e seus respectivos temas: 

<div align="center">
<sub>Tabela x - Planejamento das fases </sub>
</div>

|Fase|Marca| Background | Plataforma | Inimigo| 
|--------|---------|-----------------------| ------ | ---| 
|1|Introdução| Escritório da Unilever | Computador rackeado| Não há | 
|2|Omo| Parede com bolhas de sabão na área inferior e roupas penduradas na parte superior| Pregadores de roupa, máquina de lavar e cesto de roupas| Bactéria | 
|3|Mãe Terra| Fundo de floresta | Biscoito e pacote de bolacha | Besouro| 
|4|Dove| Parede quadriculada de banheiro com shampoo e condicionador | Barra de sabonete e caixa de sabonete| Desodorante que empurra para frente| 
|5| Kibon | Montanhas de sorvete | Canudo de chocolate e colher | Gotas de sorvete derretido| 
|6|Hellman's| Fundo de cachorro-quente | Maionese | Batata frita| 
|7|Knorr| Imitação de sopa | Colher e enlatado | Garfo | 

<div align="center">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>


### 3.3.2. Navegação pelo mundo (sprints 2 e 3)

&nbsp;&nbsp;&nbsp;&nbsp;O jogo ocorre em plataforma, sendo inspirado na dinâmica de "Super Mário Bros" de 1986. Na primeira fase, o player é abduzido por um computador que foi invadido por um hacker, o qual sequestra os produtos da Unilever. Ao ser teletransportado, o jogador vai para a próxima fase e é responsável por resgatar uma das marcas e encontrar a NPC YoUni, que entregará ao player um link do Onboarding da Unilever. 

&nbsp;&nbsp;&nbsp;&nbsp;Após isso, ele continua até o final da fase e encontra um quiz, que testa o conteúdo aprendido no link. Caso o player acerte, ele recebe uma pontuação, uma letra-chave que será essencial para desligar o sistema do invasor na última fase e a permissão para passar pelo portal que o levará à próxima fase. Entretanto, se o jogador errar, ele deve responder a mesma questão até acertar, havendo diminuição de pontos da questão a cada equívoco. A mesma dinâmica ocorre em todas as fases, mudando apenas a marca a ser resgatada. 


### 3.3.3. Condições climáticas e temporais (sprints 2 e 3)

*\<opcional\> Descreva diferentes condições de clima que podem afetar o mundo e as fases, se aplicável*

*Caso seja relevante, descreva como o tempo passa, se ele é um fator limitante ao jogo (ex. contagem de tempo para terminar uma fase)*

### 3.3.4. Concept Art (sprint 2)

&nbsp;&nbsp;&nbsp;&nbsp;Para a tela de início, pensamos em fazer "Easter eggs", ou seja, referências das próximas cenas do jogo e dos produtos da Unilever; a fim de apresentar a estética do game. A seguir, pode-se observar a concept art inicial e a sua paleta de cores <sup>15</sup>: 

<div align="center">
<sub>Figura X - Concept art da cena 0 </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/mariana%7Cedit/document/assets/Esbo%C3%A7o%20da%20cena%200.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Paleta de cores da cena 0 </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/mariana%7Cedit/document/assets/Cores%20da%20cena%200.png" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>


&nbsp;&nbsp;&nbsp;&nbsp;Já para a primeira fase, pensamos em representar o escritório da Unilever com cores saturadas e vibrantes, onde o player encontrará o computador hackeado e será teletransportado para a dimensão dos produtos da Unilever. 

<div align="center">
<sub>Figura X - Concept art da cena 1 </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/main/document/assets/Esbo%C3%A7o%20da%20cena%201.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Paleta de cores da cena 1 </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/mariana%7Cedit/document/assets/Cores%20da%20cena%201.png" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>


&nbsp;&nbsp;&nbsp;&nbsp;Para a segunda fase, criamos um background inspirado em uma lavanderia com roupas penduradas e sabão espalhado pelo chão, a fim de condizer com a "Omo". Além disso, desenhamos pregadores e máquinas de lavar como plataformas dentro dessa mesma temática e uma bactéria que representa o inimigo. Também foi criado um NPC de uma caixa da Omo para que ele seja salvo durante a cena pelo player. 

<div align="center">
<sub>Figura X - Concept art da cena 2 </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/main/document/assets/Esbo%C3%A7o%20da%20cena%202.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Paleta de cores da cena 2 </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/mariana%7Cedit/document/assets/Cores%20da%20cena%202.png" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Concept art do Omo </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/mariana%7Cedit/document/assets/Concept%20art%20do%20Omo.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Paleta de cores da Omo </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/446121a139f8e18269b5df2142c57d4d907a6d1c/document/assets/AdobeColor-color%20theme_omo.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>



&nbsp;&nbsp;&nbsp;&nbsp;Em relação à terceira fase, fizemos um campo aberto com uma árvore que representa a logo da "Mãe Terra" e algumas plantas, as quais também aparecem em várias embalagens da marca. Para representar a marca a ser resgatada, utilizamos um jacaré que aparece em alguns pacotes de biscoito. Por fim, projetamos as plataformas como bolachas e pacotes de biscoito para referenciar algumas mercadorias e utilizamos um besouro como inimigo. 

<div align="center">
<sub>Figura X - Concept art da cena 3 </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/main/document/assets/Esbo%C3%A7o%20da%20cena%203.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Paleta de cores da cena 3 </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/mariana%7Cedit/document/assets/Cores%20da%20cena%203.png" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Concept art do Jacaré Zooreta da Mãe Terra </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/mariana%7Cedit/document/assets/Concept%20art%20da%20M%C3%A3e%20Terra.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Paleta de cores do Jacaré Zooreta da Mãe Terra </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/446121a139f8e18269b5df2142c57d4d907a6d1c/document/assets/AdobeColor-color%20theme_jacar%C3%A9.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>



&nbsp;&nbsp;&nbsp;&nbsp;Para a quarta cena, pensamos em fazer um background como um fundo de banheiro que tem suportes de shampoo e condicionador e plataformas com a temática da "Dove". Também foi desenhada uma pomba como NPC a ser salvo a fim de representar a logo da marca. Ademais, o fase conta com que desodorante que empurra com um jato o jogador constantemente para a frente e uma "nuvem de fedor" como inimigo. 

<div align="center">
<sub>Figura X - Concept art da cena 4 </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/main/document/assets/Esbo%C3%A7o%20da%20cena%204.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Paleta de cores da cena 4 </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/mariana%7Cedit/document/assets/Cores%20da%20cena%204.png" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Concept art da pomba Dove </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/mariana%7Cedit/document/assets/Concept%20art%20da%20Dove.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Paleta de cores da pomba Dove </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/446121a139f8e18269b5df2142c57d4d907a6d1c/document/assets/AdobeColor-color%20theme_dove.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>


&nbsp;&nbsp;&nbsp;&nbsp;Na quinta fase, há várias bolas de sorvete com cobertura de chocolate no background e plataformas representadas por canudos de chocolate e um pote de sorvete com a logotipo da "Kibon". Para o NPC sequestrado, pensamos em utilizar o picolé "Tablito" com uma mordida na ponta. Nessa cena, o inimigo será uma calda de chocolate que está constantemente pingando gotas que, se encostarem no player, o levará a retornar a cena desde o início. 

<div align="center">
<sub>Figura X - Concept art da cena 5 </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/main/document/assets/Esbo%C3%A7o%20da%20cena%205.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Paleta de cores da cena 5 </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/mariana%7Cedit/document/assets/Cores%20da%20cena%205.png" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Concept art do Tablito Kibon </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/mariana%7Cedit/document/assets/Concept%20art%20da%20Kibon.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Paleta de cores do Tablito Kibon </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/446121a139f8e18269b5df2142c57d4d907a6d1c/document/assets/AdobeColor-color%20theme_tablito.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>


&nbsp;&nbsp;&nbsp;&nbsp;Para a sexta cena com temática "Hellmann's", fizemos um fundo de cachorro-quente e plataformas de maionese e mostarda, que contarão com um inimigo ilustrado como uma batata frita. A fase também possui um pote de maionese como NPC a ser regatado. 

<div align="center">
<sub>Figura X - Concept art da cena 6 </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/main/document/assets/Esbo%C3%A7o%20da%20cena%206.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Paleta de cores da cena 6 </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/mariana%7Cedit/document/assets/Cores%20da%20cena%206.png" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Concept art da Maionese da Hellmann's </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/mariana%7Cedit/document/assets/Concept%20art%20da%20Hellmann's.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Paleta de cores da Maionese da Hellmann's </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/446121a139f8e18269b5df2142c57d4d907a6d1c/document/assets/AdobeColor-color%20theme_Captura_maionese.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>



&nbsp;&nbsp;&nbsp;&nbsp;Na última fase jogável, utilizamos um fundo de sopa para tematizar a "Knorr" e garfos como barreiras para a passagem do jogador até seu destino final, assim como plataformas de enlatados. 

<div align="center">
<sub>Figura X - Concept art da cena 7 </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/main/document/assets/Esbo%C3%A7o%20da%20cena%207.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Paleta de cores da cena 7 </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/mariana%7Cedit/document/assets/Cores%20da%20cena%207.png" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Concept art da galinha da Knorr </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/mariana%7Cedit/document/assets/Concept%20art%20da%20Knorr.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Paleta de cores da galinha da Knorr </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/446121a139f8e18269b5df2142c57d4d907a6d1c/document/assets/AdobeColor-color%20theme_galinha.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>


&nbsp;&nbsp;&nbsp;&nbsp;Finalmente, o jogador é liberado para voltar ao escritório da Unilever, ou seja, para a cena 1; onde ele é parabenizado e tranferido para a tela final de agradecimentos ilustrada abaixo, a qual possui o tempo de jogo e a pontuação obtida durante o seu decorrer. 

<div align="center">
<sub>Figura X - Concept art da cena 8 </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/mariana%7Cedit/document/assets/Esbo%C3%A7o%20da%20cena%208.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Paleta de cores da cena 8 </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/mariana%7Cedit/document/assets/Cores%20da%20cena%208.png" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>


&nbsp;&nbsp;&nbsp;&nbsp;Caso o player tenha colidido com algum inimigo durante a partida, ele será transferido para a tela de "game over", onde ele terá que reiniciar a fase; não sendo necessário começar o jogo desde a cena inicial do escritório da Unilever. 

<div align="center">
<sub>Figura X - Concept art da cena game over </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/mariana%7Cedit/document/assets/Esbo%C3%A7o%20da%20cena%20game%20over.jpeg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura X - Paleta de cores da cena game over </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/mariana%7Cedit/document/assets/Cores%20da%20cena%20game%20over.png" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

### 3.3.5. Trilha sonora (sprint 3)

*Descreva a trilha sonora do jogo, indicando quais músicas serão utilizadas no mundo e nas fases. Utilize listas ou tabelas para organizar esta seção. Caso utilize material de terceiros em licença Creative Commons, não deixe de citar os autores/fontes.*

*Exemplo de tabela*
\# | título | ocorrência | autoria
--- | --- | --- | ---
1 | Kaze no Tani no Naushika | Tela de início | Makiko Hirohashi
2 |  Umi No Mieru Machi | Cena das plataformas | Makiko Hirohashi
3 | Kahoot Soundtrack | Tela de perguntas | Kahoot

## 3.4. Inventário e Bestiário (sprint 3)

### 3.4.1. Inventário

*\<opcional\> Caso seu jogo utilize itens ou poderes para os personagens obterem, descreva-os aqui, indicando títulos, imagens, meios de obtenção e funções no jogo. Utilize listas ou tabelas para organizar esta seção. Caso utilize material de terceiros em licença Creative Commons, não deixe de citar os autores/fontes.* 

*Exemplo de tabela*
\# | item |  | como obter | função | efeito sonoro
--- | --- | --- | --- | --- | ---
1 | moeda | <img src="assets/chico.png"> | espalhadas em todas as fases, quando encostar coleta ela | guia o jogador | som de moeda

### 3.4.2. Bestiário

*\<opcional\> Caso seu jogo tenha inimigos, descreva-os aqui, indicando nomes, imagens, momentos de aparição, funções e impactos no jogo. Utilize listas ou tabelas para organizar esta seção. Caso utilize material de terceiros em licença Creative Commons, não deixe de citar os autores/fontes.* 

*Exemplo de tabela*
\# | inimigo |  | ocorrências | função | impacto | efeito sonoro
--- | --- | --- | --- | --- | --- | ---
1 | Bacteria | <img src="assets/bacteria_OMO.png"> | Fase 1, OMO | Anda, saltitando e com velocidade constante | Se encostar no inimigo o personagem perde 1 ponto de vida | Sons de mola
2 | Besouro | <img src="assets/besouso_MT.png"> | Fase 2, Mãe Terra | Fica pulando no mesm local | Se encostar, o personagem perde 1 pontos de vida | Som de besouro
3 | Bola de Fedor | <img src=""> | Fase 3, Dove | Fica parado | Se encostar no inimigo o personagem perde 1 ponto de vida e a bolha estoura | Som de bolha estourando
4 | Nuvem de Cobertura | <img src=""> | Fase 4, Kibom | Segue o personagem pela parte superior da tela, atirando gotas de calda de sorvete | Se encostar no inimigo ou nas gotas o personagem perde 1 ponto de vida| Som calda de sorvete caindo
5 | Batata Frita Molenga | <img src=""> | Fase 5, Helmans | Corre na direção do player | Se encostar no inimigo o personagem perde 1 ponto de vida| Som de placa de metal balançando


## 3.5. Gameflow (Diagrama de cenas) (sprint 2)

<div align="center">
<sub>Figura x - Diagrama de cenas</sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/2d3e4c0bca8787489274a42e61adef31e6fa3290/document/assets/diagramacenas.jpg" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

-**Tela inicial:** o jogador começa o jogo aqui, e basta clicar na tela para que o jogo se inicie. Para o desenvolvimento desta tela, foram colocadas referências à todas as fases do jogo, como sorvete, máquina de lavar, entre outros. Para a programação desta tela, a única classe utilizada até então foi a classe "Scene00", a qual ainda não tem atributos próprios e apresenta <code>create()</code> como único método. No mais, essa classe apresenta como única herança o atibuto <code>Phaser.scenes()</code>

-**Fase 1:** pensada para ser uma introdução à dinâmica do jogo, essa fase apresenta um cenário inicial de escritório no qual o personagem principal anda por ele, aprendendo os movimentos, e encongra o "computador hackeado" no qual iniciará sua imersão no game. Por ser uma fase de tutorial, ela não apresenta possibilidade de GameOver, sendo exclusivamente uma introdução às mecânicas e dinâmicas do jogo. Para o desenvolvimento dessa fase, a única classe utilizada até então foi a "Scene01", que não tem atributos próprios e apresenta <code>preload()</code>, <code>create()</code> e <code>update()</code> como métodos. No mais, essa classe apresenta como única herança o atibuto <code>Phaser.scenes()</code>

-**Fase 2:** temática da marca "Omo", essa fase será de plataforma, e além de responder o quiz do final, o jogador deve atravessar o cenário sem encostar na bactéria - inimigo cuja colisão com o player leva ao GameOver, trazendo a necessidade de reiniciar a fase (e não o game). Para o desenvolvimento dessa fase, a única classe utilizada até então foi a "Scene02", que não tem atributos próprios e apresenta <code>preload()</code>, <code>create()</code> e <code>update()</code> como métodos. No mais, essa classe apresenta como única herança o atibuto <code>Phaser.scenes()</code>

-**Fase 3:** temática da marca "Mãe Terra", essa fase também será de plataforma, e além de responder o quiz do final, o jogador deve atravessar o cenário sem encostar no besouro - inimigo cuja colisão com o player leva ao GameOver, trazendo a necessidade de reiniciar a fase (e não o game). O desenvolvimento dessa fase ainda não foi iniciado, mas deve seguir o padrão de programação das demais e, portanto, a única classe utilizada (a priori) será a "Scene03", que não tem atributos próprios e apresenta <code>preload()</code>, <code>create()</code> e <code>update()</code> como métodos. No mais, essa classe apresenta como única herança o atibuto <code>Phaser.scenes()</code>

-**Fase 4:** temática da marca "Dove", essa fase será de plataforma, dificultada pela inserção de gravidade no eixo x - simulando a força do aerosol de um desodorante - e, além de responder o quiz do final, o jogador deve atravessar o cenário sem encostar na bolha de fedor - inimigo cuja colisão com o player leva ao GameOver, trazendo a necessidade de reiniciar a fase (e não o game). O desenvolvimento dessa fase ainda não foi iniciado, mas deve seguir o padrão de programação das demais e, portanto, a única classe utilizada (a priori) será a "Scene04", que não tem atributos próprios e apresenta <code>preload()</code>, <code>create()</code> e <code>update()</code> como métodos. No mais, essa classe apresenta como única herança o atibuto <code>Phaser.scenes()</code>

-**Fase 5:** temática da marca "Kibon", essa fase será de plataforma, dificultada pela inserção de gotas de chocolate caindo do céu e, além de responder o quiz do final, o jogador deve atravessar o cenário sem encostar nessas gotas - inimigos cuja colisão com o player leva ao GameOver, trazendo a necessidade de reiniciar a fase (e não o game). O desenvolvimento dessa fase ainda não foi iniciado, mas deve seguir o padrão de programação das demais e, portanto, a única classe utilizada (a priori) será a "Scene05", que não tem atributos próprios e apresenta <code>preload()</code>, <code>create()</code> e <code>update()</code> como métodos. No mais, essa classe apresenta como única herança o atibuto <code>Phaser.scenes()</code>

-**Fase 6:** temática da marca "Hellman's", essa fase será também de plataforma e, além de responder o quiz do final, o jogador deve atravessar o cenário sem encostar nas batatas-fritas espalhadas pelo caminho - inimigas cuja colisão com o player leva ao GameOver, trazendo a necessidade de reiniciar a fase (e não o game). Como adicional de dificuldade deste nível, o player não poderá subir nas plataformas mais altas, mas terá de se "pendurar" nelas por baixo. O desenvolvimento dessa tela ainda não foi iniciado, mas deve seguir o padrão de programação das demais e, portanto, a única classe utilizada (a priori) será a "Scene06", que não tem atributos próprios e apresenta <code>preload()</code>, <code>create()</code> e <code>update()</code> como métodos. No mais, essa classe apresenta como única herança o atibuto <code>Phaser.scenes()</code>

-**Fase 7:** temática da marca "Knorr", essa fase será não será exatamente de plataforma, mas sim um estilo de "flap birdy" estilizado no qual o player, posicionado em uma prancha, precisará navegar entre os garfor que surgem debaixo e de cima da tela e, além de responder o quiz do final, o jogador deve atravessar o cenário sem encostar nesses garfos - inimigas cuja colisão com o player leva ao GameOver, trazendo a necessidade de reiniciar a fase (e não o game). Como adicional de dificuldade deste nível, o player não poderá subir nas plataformas mais altas, mas terá de se "pendurar" nelas por baixo. O desenvolvimento dessa fase ainda não foi iniciado, mas deve seguir o padrão de programação das demais e, portanto, a única classe utilizada (a priori) será a "Scene07", que não tem atributos próprios e apresenta <code>preload()</code>, <code>create()</code> e <code>update()</code> como métodos. No mais, essa classe apresenta como única herança o atibuto <code>Phaser.scenes()</code>

-**Tela Final:** projetada para ser o encerramento do jogo, esta tela apresentará o tempo levado pelo player no jogo, assim como a pontuação conquistada por ele nas respostas aos quizzes. Como trata-se de uma tela de encerramento, as únicas possibilidaddes para o jogador dentro dela são a de sair do jogo ou a de jogar novamente. O desenvolvimento desta tela ainda não foi iniciado, mas deve seguir o padrão de programação das demais e, portanto, a única classe utilizada (a priori) será a "Scene08", que não tem atributos próprios e apresenta <code>preload()</code>, <code>create()</code> e <code>update()</code> como métodos. No mais, essa classe apresenta como única herança o atibuto <code>Phaser.scenes()</code>

-**Tela GameOver:** essa é a tela que o jogador verá ao encostar em um inimigo, ou seja, quando perder o jogo. Visto que na concepção do jogo os autores decidiram por não possibilitar o retorno a fases anteriores, a tela de GameOver tem como única possibilidade o reinicio da fase que foi perdida, e não permite o reinicio do jogo inteiro. O desenvolvimento desta tela ainda não foi iniciado, mas deve seguir o padrão de programação das demais e, portanto, a única classe utilizada (a priori) será a "Scene08", que não tem atributos próprios e apresenta <code>preload()</code>, <code>create()</code> e <code>update()</code> como métodos. No mais, essa classe apresenta como única herança o atibuto <code>Phaser.scenes()</code>

## 3.6. Regras do jogo (sprint 3)

&nbsp;&nbsp;&nbsp;&nbsp; O jogador deve subir nas plataformas, desviar dos inimigos e de buracos no chão com o objetivo de resgatar a marca temática da presente fase em que ele está. O jogador terá três vidas por fase, caso ele caia nas fendas ou colida com inimigos, uma vida será perdida e ele somente voltará para o início da fase se perder todas as vidas. Para passar para a próxima cena, o player deve responder corretamente um quiz referente ao conteúdo aprendido no link e guardar a letra-chave no seu inventário após acertar a pergunta. Abaixo, segue uma tabela com as pontuações recebidas pelas respostas corretas:  

<div align="center">
<sub>Tabela X - Pontuação por tentativas de resposta</sub>


|Tentativas até acertar a questão| Pontuação recebida| 
|---|---| 
|1| 4| 
|2|2| 
|3|1| 
|4|0| 


<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

Ao passar para a próxima fase do jogo, o player não poderá retornar a elas, já que eles poderiam responder as questões novamente e mudar a sua pontuação final, que representa o seu nível de aproveitamento do Onboarding. Entretanto, ele terá acesso ao conteúdo do Onboarding ao acessar os links que serão incorporados ao seu inventário a cada fase passada. Após terminar todas as fases, o player deve acessar o computador e digitar as letras-chave para bloquear o sistema do hacker. 



## 3.7. Mecânicas do jogo (sprint 3)

&nbsp;&nbsp;&nbsp;&nbsp;O jogo ocorre em plataforma e o jogador pode ser controlado pelas setas "direita", "esquerda" e "cima" do teclado, que fazem o player se movimentar para frente, para trás e pular, respectivamente. Para interagir com NPC's e responder os quizes, deve-se clicar nos referidos com o mouse. Além disso, o player pode saltar nas plataformas, que estão flutuando durante as fases, e deverá fugir dos inimigos, os quais farão o jogador ser transferido à tela de game over e voltar para o início da fase caso eles colidam. Na fase da Kibon a dinâmica do inimigo será diferente, já que ele imitará uma cobertura de sorvete pingando; entretanto a regra de game over também será válida para essa cena.  Ademais, na fase da "Dove" haverá um desodorante que empurrará o player para a frente por meio de um jato constante, que o deslocará no eixo x para a direita. Por fim, na fase da "Knorr" o jogador deverá pressionar a tecla "espaço" a fim de fazer seu personagens voar, já que essa fase segue a mesma dinâmica de "Flappy Bird".

# <a name="c4"></a>4. Desenvolvimento do Jogo

## 4.1. Desenvolvimento preliminar do jogo (sprint 1)


### 4.1.1 O que fizemos
&nbsp;&nbsp;&nbsp;&nbsp;Até o momento, nosso grupo se dedicou ao desenvolvimento do personagem do jogo, o que incluiu a definição da estética desejada e a criação de imagens para animação em diferentes ângulos: de frente, lado e de costas. Em termos de programação, implementamos a movimentação do personagem, permitindo-o mover-se para frente, para trás e para os lados. Além disso, integramos o cenário ao jogo e adicionamos a animação, que consiste em alterar a imagem do personagem conforme ele se move em diferentes direções. Adicionalmente, garantimos que a movimentação do personagem respeite os limites do cenário.

### 4.1.2 Desafios
&nbsp;&nbsp;&nbsp;&nbsp;Durante o desenvolvimento dessa primeira sprint tivemos dificuldades com a sintaxe do Javascript, uma vez que diversos erros ocorreram devido à ausência de vírgulas e à escrita errada de palavras. 
Também ocorreram empecilhos em relação à animação do personagem, já que tivemos que utilizar uma spritesheet piloto que não possuía todas as sprites; contudo, conseguimos escrever a programação básica da animação, a qual pode ser facilmente editada quando a spritesheet oficial for finalizada. Além disso, a criação da animação da posição de costas do player causou complicações, visto que o jogo travava quando a tecla "cima" era pressionada, ou seja, quando o personagem virava de costas. Entretanto, isso foi concertado a partir da revisão gramatical da função “this.anims.create”.


### 4.1.3 O que precisamos fazer
&nbsp;&nbsp;&nbsp;&nbsp;Nossos próximos passos para o jogo envolvem aprimorar o cenário, pois o atual limita bastante a experiência de jogo, já que o personagem ocupa uma grande parte da tela. Isso incluiria a criação de novas estruturas e objetos que o personagem poderia interagir e aprimorar. Além disso, é crucial desenvolvermos cenas, o que significa que o jogo teria uma tela inicial onde ao pressionar uma tecla, iniciaria e mudaria de cena.

&nbsp;&nbsp;&nbsp;&nbsp;Em relação ao personagem, decidimos que seria mais harmonioso se a câmera do jogo acompanhasse seus movimentos, o que contribuiria para a fluidez da jogabilidade.


## 4.2. Desenvolvimento básico do jogo (sprint 2)

Semana 1-2 (Jogo Isométrico):
- Durante as primeiras duas semanas, o jogo estava sendo desenvolvido como um jogo isométrico.
- Criação de assets isométricos, design de níveis e sistemas de jogo específicos para esse formato.
- A mudança de cenas foi programada nesse espaço de tempo
- Tela de início
  <img src="assets/print_jogo_semana1.png" width="100%">
  <img src="assets/tela de inicio_semana1.png" width="100%">

Semana 3 (Transição para um “platformer”):
- Mudança do time de programação (Mariana e Eduardo -> Felipe e Lucas)
- mudança no paradigma, jogo isométrico, para um jogo “platformer” 2D
- implicou ajustes significativos nos assets, design de níveis, mecânicas de jogo e código
- compreensão do código antigo para tentar aproveitar o máximo durante essa transição
- início da cena 1 (início do jogo)

   Problema no Código de Digitação (Dias 1-4 da Semana 3):
    - Um erro de digitação acabou por atrasar a produção
    - Houve consideração para uma reescrita completa do código, mas isso foi evitado após a resolução do problema
   Programação Fluída (Após Resolução do Problema):
    - a programação do jogo ocorreu de forma fluida após esse ocorrido
    - início da implementação das mecânicas básicas
    -  O desenvolvimento se concentrou em implementar as mecânicas de “platformer” 2D, ajustar a física do jogo e integrar os novos assets
Semana 4
- finalização da implementação das mecânicas básicas
- finalização da cena 1
- comentários no código
- revisão do código
- início da cena 2 (Fase da Omo)
- Entregáveis da Versão Básica:
  <img src="assets/cena0_semana3.png" width="100%"> 
Uma versão básica do jogo foi entregue com os seguintes elementos:
- Mecânicas de “platformer” 2D funcionais
- Carregamento adequado de assets
- Design de níveis adaptado ao novo formato
- Correções de bugs relacionados à transição
Dificuldades:
- O principal desafio foi o problema no código de digitação que afetou o carregamento de imagens
- A transição rápida de um estilo de jogo para outro pode ter causado algumas complicações iniciais na integração dos sistemas
Próximos Passos:
- aprimorar as mecânicas e adicionar novas
- Realizar testes para identificar e corrigir possíveis bugs
- Adicionar novas fases 


## 4.3. Desenvolvimento intermediário do jogo (sprint 3)

&nbsp;&nbsp;&nbsp;&nbsp;O desenvolvimento da versão intermediária do jogo se deu com a elaboração do level design da cena 02 (fase da OMO) e a programação desta, adicionando ao jogo: plataformas, inimigos, recursos visuais do tipo affordance - que melhoram a jogabilidade e a tornam mais intuitiva - e a transição para a próxima fase, feita através de um portal no final do mapa. Ademais, foi desenvolvida uma nova tela inicial e botões funcionais para interagir com o game, juntamente com a tela de gameover quando o player cai um espaço sem chão ou quando encosta em um dos inimigos. Em conclusão, essa sprint entrega a primeira fase jogável com desafios e conquistas, uma jogabilidade mais intuitiva e coerente com a proposta e uma prévia da próxima tela, a fase da Mãe Terra. 

&nbsp;&nbsp;&nbsp;&nbsp;Em termos de código, foram excluídas as variáveis vazias, adicionadas novas funções de colisão, transição de telas e interatividade - o uso dos botões -, e incluídos novos testes de gravidade, diâmetro de pulo e variações de tamanho dos personagens. 

&nbsp;&nbsp;&nbsp;&nbsp;As próximas dificuldades estão em: manter a jogabilidade fluida e em um nível coerente de esforço do player, implementar as falas nas linhas de texto e garantir o entendimento total da proposta de cada fase. Pensando em mitigar esses problemas, os próximos passos se concentram em aumentar os casos de teste - sobretudo com pessoas que não jogam com frequência - para garantir a adequação dos padrões de habilidades e aumentar o time de programação para tornar o desenvolvimento mais ágil.

<div align="center">
<sub>Figura x - Nova tela de início com botão funcional</sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/0db026c82376b6be234ffeb79841e0470504f564/document/assets/nova%20tela%20de%20inicio.png" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura x - Nova tela de gameover</sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/0db026c82376b6be234ffeb79841e0470504f564/document/assets/nova%20tela%20de%20gameover.png" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura x - Funções de colisão que permitem o personagem subir e se manter </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/0db026c82376b6be234ffeb79841e0470504f564/document/assets/funcionamento%20das%20colis%C3%B5es.png" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Figura x - Prévia da fase: Mãe Terra, acessada por um portal na fase OMO </sub>
<img src="https://github.com/Inteli-College/2024-T0012-IN01-G01/blob/0db026c82376b6be234ffeb79841e0470504f564/document/assets/preview%20mae%20terra.png" width="100%">
<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>


## 4.4. Desenvolvimento final do MVP (sprint 4)

*Descreva e ilustre aqui o desenvolvimento da versão final do jogo, explicando brevemente o que foi entregue em termos de MVP. Utilize prints de tela para ilustrar. Indique as eventuais dificuldades e planos futuros.*

## 4.5. Revisão do MVP (sprint 5)

*Descreva e ilustre aqui o desenvolvimento dos refinamentos e revisões da versão final do jogo, explicando brevemente o que foi entregue em termos de MVP. Utilize prints de tela para ilustrar.*

# <a name="c5"></a>5. Testes (sprint 4)

## 5.1. Casos de Teste

*Descreva nesta seção os casos de teste comuns que podem ser executados a qualquer momento para testar o funcionamento e integração das partes do jogo. Utilize tabelas para facilitar a organização.*

*Exemplo de tabela*
\# | pré-condição | descrição do teste | pós-condição 
--- | --- | --- | --- 
1 | --- | o jogo começar do início | o jogo deve iniciar na cena 00
2 | Cena 00 | Clicar no botão esquerdo do mouse | mudar para a cena 01
3 | Cena 01 | Clicar na seta esquerda | O player se move para a esquerda
4 | Cena 01 | Clicar na seta direita | O player se move para a direita
5 | Cena 01 | Clicar na seta de cima | O player pula
6 | Cena 01 | Colidir com o player na área do Ponto de Exclamação | mudar para a cena 02
 

## 5.2. Testes de jogabilidade (playtests) (sprint 4)

### 5.2.1 Registros de testes

*Descreva nesta seção as sessões de teste/entrevista com diferentes jogadores. Registre cada teste conforme o template a seguir.*
<div align="center">
<sub>Tabela de testes - Testador 01</sub>

Nome | Jorge silva
--- | ---
Já possuía experiência prévia com games? | Sim, é um jogador casual
Conseguiu iniciar o jogo? | Sim
Entendeu as regras e mecânicas do jogo? |Entendeu as mecânicas, mas teve leves dificuldades para indentificar que o inimigo não poderia ser derrotado e pulou na cabeça dele
Conseguiu progredir no jogo? | Sim, sem dificuldades  
Apresentou dificuldades? | Sim, com o inimigo que não conseguiu identificar que não poderia derrota-lo
Que nota deu ao jogo? | 7.0
O que gostou no jogo? | Gostou dos gráficos e da arte
O que poderia melhorar no jogo? | Aumentar a gravidade

<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Tabela de testes - Testador 02</sub>

Nome | Andrea Eisenhauer
--- | ---
Já possuía experiência prévia com games? | Sim, é um jogador casual
Conseguiu iniciar o jogo? | Sim
Entendeu as regras e mecânicas do jogo? |Entendeu as mecânicas, mas teve leves dificuldades para entender as regras
Conseguiu progredir no jogo? | Sim, sem dificuldades  
Apresentou dificuldades? | Sim, na página inicial teve dificuldades para entender ao certo no que deveria clicar para o jogo iniciar
Que nota deu ao jogo? | 8.0
O que gostou no jogo? | Gostou da estética do game
O que poderia melhorar no jogo? | Valor da gravidade, contextualização da cena inicial e tempo de pulo.

<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Tabela de testes - Testador 03</sub>

Nome | Ludmila Leitnerová
--- | ---
Já possuía experiência prévia com games? | Sim, é um jogador casual
Conseguiu iniciar o jogo? | Sim
Entendeu as regras e mecânicas do jogo? |Entendeu as mecânicas, mas teve leves dificuldades para entender as regras
Conseguiu progredir no jogo? | Sim, sem dificuldades  
Apresentou dificuldades? | Sim, na página inicial teve dificuldades para entender ao certo no que deveria clicar para o jogo iniciar
Que nota deu ao jogo? | 7.0
O que gostou no jogo? | Gostou da estética do game
O que poderia melhorar no jogo? | Valor da gravidade e tempo de pulo.

<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Tabela de testes - Testador 04</sub>

Nome | Nicolash Costa
--- | ---
Já possuía experiência prévia com games? | Não, quase não possui experiência com games
Conseguiu iniciar o jogo? | Sim
Entendeu as regras e mecânicas do jogo? |Não conseguiu entender as regras, mas conseguiu entender as dinâmicas por meio de tentativas, pela falta de uma explicação detalhada da dinâmica do jogo.
Conseguiu progredir no jogo? | Sim
Apresentou dificuldades? | Sim, apresentou dificuldades para passar do inimigo.
Que nota deu ao jogo? | 8.5
O que gostou no jogo? | Arte
O que poderia melhorar no jogo? | Gravidade e fluidez dos movimentos da personagem.

<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Tabela de testes - Testador 05</sub>

Nome | Tânia Rodrigues
--- | ---
Já possuía experiência prévia com games? | Sim
Conseguiu iniciar o jogo? | Sim
Entendeu as regras e mecânicas do jogo? |Regras não, mecânica sim
Conseguiu progredir no jogo? | Sim
Apresentou dificuldades? | Sim, não entendeu aonde clicar para começar e não entendeu que a bactéria era um inimigo até morrer para ela
Que nota deu ao jogo? | 9
O que gostou no jogo? | Arte
O que poderia melhorar no jogo? | Gravidade e affordance da bacteria como inimigo

<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Tabela de testes - Testador 06</sub>

Nome | Eduardo Castro
--- | ---
Já possuía experiência prévia com games? | Sim, é um jogador casual
Conseguiu iniciar o jogo? | Sim
Entendeu as regras e mecânicas do jogo? |Entendeu as mecânicas, mas teve leves dificuldades para indentificar que o inimigo não poderia ser derrotado e pulou na cabeça dele
Conseguiu progredir no jogo? | Sim, sem dificuldades
Apresentou dificuldades? | Não
Que nota deu ao jogo? | 8.5
O que gostou no jogo? | Ele gostou das artes e da movimentação
O que poderia melhorar no jogo? | Poderia ter uma aviso mostrando que não poderia encostar no inimigo.

<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>

<div align="center">
<sub>Tabela de testes - Testador 07</sub>

Nome | Rafaela Cavalcanti
--- | ---
Já possuía experiência prévia com games? | Sim, é um jogador casual
Conseguiu iniciar o jogo? | Sim
Entendeu as regras e mecânicas do jogo? |Entendeu as mecânicas, mas teve leves dificuldades para entender as regras
Conseguiu progredir no jogo? | Sim, sem dificuldades
Apresentou dificuldades? | Não, conseguiu jogar com facilidade e afirmou ser fácil
Que nota deu ao jogo? | 9
O que gostou no jogo? | 
O que poderia melhorar no jogo? | A responsividade do personagem aos controles, disse que havia um pouco de atraso desde o momento do comando até a resposta do personagem.

<sup>Fonte: Material produzido pelos autores (2024)</sup>
</div>
### 5.2.2 Melhorias

*Descreva nesta seção um plano de melhorias sobre o jogo, com base nos resultados dos testes de jogabilidade*

# <a name="c6"></a>6. Conclusões e trabalhos futuros (sprint 5)

*Escreva de que formas a solução do jogo atingiu os objetivos descritos na seção 1 deste documento. Indique pontos fortes e pontos a melhorar de maneira geral.*

*Relacione os pontos de melhorias evidenciados nos testes com plano de ações para serem implementadas no jogo. O grupo não precisa implementá-las, pode deixar registrado aqui o plano para futuros desenvolvimentos.*

*Relacione também quaisquer ideias que o grupo tenha para melhorias futuras*

# <a name="c7"></a>7. Referências (sprint 5)

1. GOUVEIA, F. Indústria de alimentos: no caminho da inovação e de novos produtos. Inovação Uniemp, v. 2, n. 5, p. 32–37, 1 dez. 2006.
‌2. JULIBONI, M. As maiores empresas de bens de consumo, segundo Melhores e Maiores. Disponível em: <https://exame.com/negocios/as-maiores-empresas-de-bens-de-consumo-segundo-melhores-e-maiores/>. Acesso em: 11 mar. 2024. 
3. JULIBONI, M. As maiores empresas de bens de consumo, segundo Melhores e Maiores. Disponível em: <https://exame.com/negocios/as-maiores-empresas-de-bens-de-consumo-segundo-melhores-e-maiores/>. Acesso em: 11 mar. 20224
4. JULIBONI, M. As maiores empresas de bens de consumo, segundo Melhores e Maiores. Disponível em: <https://exame.com/negocios/as-maiores-empresas-de-bens-de-consumo-segundo-melhores-e-maiores/>. Acesso em: 11 mar. 20224
5. AVENUE. Procter & Gamble (PG): Resultado Corporativo- 3T23. Disponível em: <https://avenue.us/resultados-trimestrais/procter-gamble-3t23/#:~:text=Suas%20a>. Acesso em: 11 mar. 2024. 
6. Arrecadação federal alcança R$ 2,218 trilhões em 2022, melhor resultado desde 1995. Disponível em: <https://www.gov.br/receitafederal/pt-br/assuntos/noticias/2023/janeiro/arrecadacao-federal-alcanca-mais-de-r-2-21-trilhoes-no-acumulado-de-janeiro-a-dezembro-de-2022#:~:text=As%20receitas%20administradas%20pela%20Receita>. Acesso em: 11 mar. 2024. 
7. FIGUEIREDO, O. Diferenciação de produtos, diversificação e lucratividade na indústria brasileira. Revista de Administração de Empresas, v. 23, n. 3, p. 33–40, 1983. 
8. CASAROTTO, C. Análise SWOT ou FOFA: o que é, como fazer e modelo grátis! Rock Content, 20 dez. 2019. 
9. UNILEVER PLC. Programa De Estágio 2023 Da Unilever Abre Inscrições. Disponível em: <https://www.unilever.com.br/news/2022/programa-de-estagio-2023-da-unilever-abre-inscricoes/#:~:text=Com%20o%20programa%20hibridUs%2C%20que>. Acesso em: 13 fev. 2024. 
10. STRATEGYZER. Strategyzer’s Value Proposition Canvas Explained. YouTube, 7 mar. 2017. Disponível em: <https://www.youtube.com/watch?v=ReM1uqmVfP0>
11. WTorre Morumbi. Disponível em: <https://spcorporate.com.br/imoveis/wtorre-morumbi>. Acesso em: 11 mar. 2024. 
12. Unilever Reviews. Disponível em: <https://www.glassdoor.com/Reviews/Unilever-Reviews-E3513.htm>. 
13. MALAR, J. P. Entenda o que é o metaverso e por que ele pode não estar tão distante de você. Disponível em: <https://www.cnnbrasil.com.br/economia/entenda-o-que-e-o-metaverso-e-por-que-ele-pode-nao-estar-tao-distante-de-voce/>. 
14. LinkedIn Login, Sign in. Disponível em: <https://www.linkedin.com/company/unilever/people/?facetNetwork=F&keywords=ti>. 
15. COOLORS. Pick palette from photo - Coolors. Disponível em: <https://coolors.co/image-picker>. 


# <a name="c8"></a>Anexos

*Inclua aqui quaisquer complementos para seu projeto, como diagramas, imagens, tabelas etc. Organize em subtópicos utilizando headings menores (use ## ou ### para isso)*
